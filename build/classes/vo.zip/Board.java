package vo;

public class Board {
	
	private int boardnum;
	private String save_filenum;
	private String title;
	private String content;
	
	public Board() {
		// TODO Auto-generated constructor stub
	}

	public Board(int boardnum, String save_filenum, String title, String content) {
		super();
		this.boardnum = boardnum;
		this.save_filenum = save_filenum;
		this.title = title;
		this.content = content;
	}

	public int getBoardnum() {
		return boardnum;
	}

	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}

	public String getSave_filenum() {
		return save_filenum;
	}

	public void setSave_filenum(String save_filenum) {
		this.save_filenum = save_filenum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "Board [boardnum=" + boardnum + ", save_filenum=" + save_filenum + ", title=" + title + ", content="
				+ content + "]";
	}
	
	
}
