package vo;

public class MemberGroup {

	private int groupnum;
	private String groupname;
	private String save_filenum;
	private String leaderno;
	
    public MemberGroup() {
		// TODO Auto-generated constructor stub
	}

	public MemberGroup(int groupnum, String groupname, String save_filenum, String leaderno) {
		super();
		this.groupnum = groupnum;
		this.groupname = groupname;
		this.save_filenum = save_filenum;
		this.leaderno = leaderno;
	}

	public int getGroupnum() {
		return groupnum;
	}

	public void setGroupnum(int groupnum) {
		this.groupnum = groupnum;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getSave_filenum() {
		return save_filenum;
	}

	public void setSave_filenum(String save_filenum) {
		this.save_filenum = save_filenum;
	}

	public String getLeaderno() {
		return leaderno;
	}

	public void setLeaderno(String leaderno) {
		this.leaderno = leaderno;
	}

	@Override
	public String toString() {
		return "MemberGroup [groupnum=" + groupnum + ", groupname=" + groupname + ", save_filenum=" + save_filenum
				+ ", leaderno=" + leaderno + "]";
	}
    
    
}
